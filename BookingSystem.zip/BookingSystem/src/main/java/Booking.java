
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author M.Farhan
 */
public class Booking {
     private String customerName;
    private String customerCnic;
    private String customerContact;
    private String customerEmail;
    private String customerAddress;
    private String vehicleType;
    private String vehicleModel;
    private String vehicleRegNo;
    private String vehicleSeatingCapacity;
    private String bookingLocation;
    private String bookingDestination;
    private String bookingRent;
    private String driverName;
    private String driverCnic;

    // Constructor to initialize booking data
    public Booking(String customerName, String customerCnic, String customerContact, String customerEmail, String customerAddress,
                   String vehicleType, String vehicleModel, String vehicleRegNo, String vehicleSeatingCapacity,
                   String bookingLocation, String bookingDestination, String bookingRent,
                   String driverName, String driverCnic) {
        this.customerName = customerName;
        this.customerCnic = customerCnic;
        this.customerContact = customerContact;
        this.customerEmail = customerEmail;
        this.customerAddress = customerAddress;
        this.vehicleType = vehicleType;
        this.vehicleModel = vehicleModel;
        this.vehicleRegNo = vehicleRegNo;
        this.vehicleSeatingCapacity = vehicleSeatingCapacity;
        this.bookingLocation = bookingLocation;
        this.bookingDestination = bookingDestination;
        this.bookingRent = bookingRent;
        this.driverName = driverName;
        this.driverCnic = driverCnic;
    }

    // Method to save booking data to the file
    public static void saveBooking(Booking booking) {
        File file = new File("C:\\Users\\M.Farhan\\Desktop\\BookingSystemFiles\\Bookings.txt");

        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(file, true)); // Open in append mode
            writer.write(booking.customerName + "," + booking.customerCnic + "," + booking.customerContact + ","
                    + booking.customerEmail + "," + booking.customerAddress + "," + booking.vehicleType + ","
                    + booking.vehicleModel + "," + booking.vehicleRegNo + "," + booking.vehicleSeatingCapacity + ","
                    + booking.bookingLocation + "," + booking.bookingDestination + "," + booking.bookingRent + ","
                    + booking.driverName + "," + booking.driverCnic);
            writer.newLine();
            writer.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error while saving booking information.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
}
