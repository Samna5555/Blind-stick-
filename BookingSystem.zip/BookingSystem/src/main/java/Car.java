import java.awt.List;
import java.io.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author M.Farhan
 */
public class Car {
    // Data members for car details
     String regNo;
     String model;
     String type;
     String seatingCapacity;

    // Constructor to initialize the Car object
    public Car(String regNo, String model, String type, String seatingCapacity) {
        this.regNo = regNo;
        this.model = model;
        this.type = type;
        this.seatingCapacity = seatingCapacity;
    }

    // Method to add car info to the file
    public boolean addCar() {
    File file = new File("C:\\Users\\M.Farhan\\Desktop\\BookingSystemFiles\\Cars.txt");  // File where car data will be stored

    // Check if the registration number already exists in the file
    if (isCarExists(regNo)) {
        // Show a popup message if the car already exists
        JOptionPane.showMessageDialog(null, "Car with this registration number already exists!", "Error", JOptionPane.ERROR_MESSAGE);
        
       
        return false;  // Return false if car already exists
    }

    // Add the new car to the file if registration number doesn't exist
    try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) {
        // Write the car details to the file (comma-separated values)
        writer.write(regNo + "," + model + "," + type + "," + seatingCapacity);
        writer.newLine();  // Add a new line for the next car
        return true;  // Return true if car is successfully added
    } catch (IOException e) {
        JOptionPane.showMessageDialog(null, "Error while saving car information.", "Error", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();  // Print stack trace for debugging purposes
        return false;  // Return false if an error occurred
    }
}

    // Method to check if a car with the given registration number already exists in the file
    private boolean isCarExists(String regNo) {
        File file = new File("C:\\Users\\M.Farhan\\Desktop\\BookingSystemFiles\\Cars.txt");

        // If the file doesn't exist, return false (no cars in the file)
        if (!file.exists()) {
            return false;
        }

        // Try reading the file to check if the registration number exists
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Split the line into car details (RegNo, Model, Type, SeatingCapacity)
                String[] carData = line.split(",");
                String savedRegNo = carData[0];  // RegNo is the first element in the line

                // Compare the entered regNo with the saved regNo
                if (savedRegNo.equals(regNo)) {
                    return true;  // Car with the same regNo exists
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error while checking car information.", "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();  // Print stack trace for debugging purposes
        }

        return false;  // No matching car found
    }
    
    
    public static boolean deleteCar(String regNo) {
        
        File file = new File("C:\\Users\\M.Farhan\\Desktop\\BookingSystemFiles\\Cars.txt");

        // Create a temporary List to store the remaining car data after deletion
        ArrayList<String> updatedData = new ArrayList<>();

        boolean carDeleted = false;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;

            // Read all lines from the file
            while ((line = reader.readLine()) != null) {
                String[] carDetails = line.split(",");
                String currentRegNo = carDetails[0];  // Registration number is the first field

                // If the registration number matches, skip writing it to the updated list (i.e., delete the car)
                if (currentRegNo.equals(regNo)) {
                    carDeleted = true;
                } else {
                    updatedData.add(line); // Add the remaining cars to the list
                }
            }

            if (carDeleted) {
                // Overwrite the original file with the updated data (without the deleted car)
                try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
                    for (String carData : updatedData) {
                        writer.write(carData);
                        writer.newLine();  // Write each car data to the file
                        
                    }

                    JOptionPane.showMessageDialog(null, "Car deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Car with this registration number not found!", "Error", JOptionPane.ERROR_MESSAGE);
                
            }

        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error occurred while deleting the car.", "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
        return carDeleted;
    }
    
}
