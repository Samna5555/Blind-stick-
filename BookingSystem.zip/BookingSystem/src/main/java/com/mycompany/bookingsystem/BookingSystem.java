/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bookingsystem;

/**
 *
 * @author M.Farhan
 */
public class BookingSystem {

    public static void main(String[] args) {
        
    }
}
