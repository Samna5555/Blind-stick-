import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author M.Farhan
 */
public class Admin {
    String FirstName, LastName, UserName, Password, Contact, Address;
    public Admin(String firstName, String lastName, String userName, String password, String contact, String address) {
        this.FirstName = firstName;
        this.LastName = lastName;
        this.UserName = userName;
        this.Password = password;
        this.Contact = contact;
        this.Address = address;
        
        // Store the values in a file
        saveToFile();
    }
    private void saveToFile() {
        // Define the file where data will be stored
        File file = new File("C:\\Users\\M.Farhan\\Desktop\\BookingSystemFiles\\Admin.txt");  // You can change the path and file name as needed

        try {
            // Create a FileWriter wrapped in BufferedWriter for efficiency
            BufferedWriter writer = new BufferedWriter(new FileWriter(file, true)); // 'true' to append to the file

            // Write the data in CSV format
            writer.write(this.FirstName + "," + this.LastName + "," + this.UserName + "," + this.Password + "," + this.Contact + "," + this.Address);
            writer.newLine(); // Add a new line after each entry

            // Close the writer
            writer.close();

            // Show success popup message
            JOptionPane.showMessageDialog(null, "Data saved successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            // Show error popup message
            JOptionPane.showMessageDialog(null, "An error occurred while saving the data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    
    }
}
