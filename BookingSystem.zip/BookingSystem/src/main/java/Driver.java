
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author M.Farhan
 */
public class Driver {
     // Attributes of Driver class
     String name;
     String cnic;
     String phoneNumber;
     String address;

    // Constructor to initialize the attributes
    public Driver(String name, String cnic, String phoneNumber, String address) {
        this.name = name;
        this.cnic = cnic;
        this.phoneNumber = phoneNumber;
        this.address = address;
    }

    // Method to add a driver to the file, checking if CNIC already exists
    public static boolean addDriver(Driver driver) {
        File file = new File("C:\\Users\\M.Farhan\\Desktop\\BookingSystemFiles\\Drivers.txt");
        boolean check=false;
        // Check if the driver already exists based on CNIC
        if (driverExists(driver.cnic)) {
            // If CNIC already exists, show a popup message
            JOptionPane.showMessageDialog(null, "Driver with this CNIC already exists!", "Error", JOptionPane.ERROR_MESSAGE);
            check=true;
             // Exit the method if driver exists
        }
        else{

        // Try with resources to handle file IO operations
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) { // 'true' for append mode
            // Format the driver information as a CSV line
            String driverInfo = driver.name + "," + driver.cnic + "," + driver.phoneNumber + "," + driver.address;

            // Write the driver information to the file
            writer.write(driverInfo);
            writer.newLine();  // Add a new line for the next driver

            // Show success message
            JOptionPane.showMessageDialog(null, "Driver added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            // Show error message if something goes wrong
            JOptionPane.showMessageDialog(null, "Error occurred while adding the driver.", "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
        }
        return check;
    }

    // Method to check if a driver with the given CNIC already exists in the file
    private static boolean driverExists(String cnic) {
        File file = new File("C:\\Users\\M.Farhan\\Desktop\\BookingSystemFiles\\Drivers.txt");

        

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            // Read the file line by line
            while ((line = reader.readLine()) != null) {
                String[] driverData = line.split(",");
                String existingCnic = driverData[1];  // CNIC is the second field in the file

                // If the CNIC matches, the driver already exists
                if (existingCnic.equals(cnic)) {
                    return true;
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "An error occurred while deleting the driver.", "Error", JOptionPane.ERROR_MESSAGE);
        }

        return false;  // If no matching CNIC is found, the driver doesn't exist
    }
    
     public static boolean deleteDriver(String cnic) {
        File file = new File("C:\\Users\\M.Farhan\\Desktop\\BookingSystemFiles\\Drivers.txt");
        boolean driverFound = false;

        try {
            // Read all the lines from the file
            BufferedReader reader = new BufferedReader(new FileReader(file));
            StringBuilder fileContent = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                String[] driverData = line.split(",");
                String existingCnic = driverData[1];  // CNIC is the second field in the file

                // If CNIC matches, skip this line (this means the driver will be deleted)
                if (existingCnic.equals(cnic)) {
                    driverFound = true;  // Mark that we found the driver to delete
                    continue;  // Skip writing this line (delete it)
                }

                // Otherwise, add this line to the file content
                fileContent.append(line).append(System.lineSeparator());
            }
            reader.close();

            // If driver was found, overwrite the file with the updated content
            if (driverFound) {
                // Write the updated content back to the file
                BufferedWriter writer = new BufferedWriter(new FileWriter(file));
                writer.write(fileContent.toString());
                writer.close();

                // Show success message
                JOptionPane.showMessageDialog(null, "Driver deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                // Show error message if the driver was not found
                JOptionPane.showMessageDialog(null, "Driver with this CNIC not found.", "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "An error occurred while deleting the driver.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return driverFound;
    }
    
}
